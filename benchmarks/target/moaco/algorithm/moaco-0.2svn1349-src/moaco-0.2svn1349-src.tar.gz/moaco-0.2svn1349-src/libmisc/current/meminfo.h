int getVmSize(void);
int getVmRSS(void);

