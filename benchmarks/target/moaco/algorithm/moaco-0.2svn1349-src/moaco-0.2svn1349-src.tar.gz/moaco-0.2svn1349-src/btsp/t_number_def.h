/* t_number: a long number, which can be implemented as long, int, int64 or double
 * Should be used in data related to the objective functions, like distances, costs, weights, profits
 */
#define T_NUMBER_IS T_NUMBER_IS_INT_FAST64
#include "t_number.h"

