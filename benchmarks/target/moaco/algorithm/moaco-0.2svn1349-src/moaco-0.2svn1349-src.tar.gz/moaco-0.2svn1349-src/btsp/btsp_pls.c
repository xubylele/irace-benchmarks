#include "btsp.h"
#include "pareto.h"

void 
ParetoLocalSearch(t_Pareto * pareto  __unused)
{
    eprintf ("PLS not implemented yet for bTSP\n");
}
