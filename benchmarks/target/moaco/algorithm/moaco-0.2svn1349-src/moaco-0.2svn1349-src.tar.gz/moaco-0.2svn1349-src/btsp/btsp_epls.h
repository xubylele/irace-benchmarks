#ifndef _EPLS_H_
#define _EPLS_H_


struct t_Pareto;

void 
eParetoLocalSearch(struct t_Pareto * pareto, double allowable_tolerance);

#endif
