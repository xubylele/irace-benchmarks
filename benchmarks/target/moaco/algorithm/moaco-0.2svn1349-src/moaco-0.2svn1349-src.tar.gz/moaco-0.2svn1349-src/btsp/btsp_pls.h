#ifndef _PLS_H_
#define _PLS_H_

struct t_Pareto; /* Forward declaration to avoid circular dependency */

void
ParetoLocalSearch(struct t_Pareto * pareto);

#endif
