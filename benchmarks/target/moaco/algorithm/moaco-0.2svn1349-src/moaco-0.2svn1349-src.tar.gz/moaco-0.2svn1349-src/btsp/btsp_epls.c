#include "btsp.h"
#include "pareto.h"

void 
eParetoLocalSearch(t_Pareto * pareto  __unused, double allowable_tolerance __unused)
{
    eprintf ("ePLS not implemented yet for bTSP\n");
}
