#ifndef SPEA_SELECTION_H
#define SPEA_SELECTION_H

void SPEA2_selection(t_Pareto *input_pareto, t_Pareto *spea2_pareto, 
                     int alpha, int pareto_maxsize);

#endif /* !SPEA_SELECTION_H */
